import React from "react";

const Home = () => {
  return <div>Homeeeeeeeeeeeee</div>;
};

export default Home;
