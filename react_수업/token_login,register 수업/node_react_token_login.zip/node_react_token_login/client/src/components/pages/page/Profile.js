import React from "react";

const Profile = ({ user }) => {
  return <div>Afer Login Page</div>;
};

export default Profile;
