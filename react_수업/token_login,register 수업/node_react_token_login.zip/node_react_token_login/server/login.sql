use reactjs;

create table login(
email varchar(50),
passwd varchar(255)
);