require("dotenv").config();
const cors = require("cors");
const mysql = require("mysql");
const express = require("express");
const app = express();

//db
const db = mysql.createConnection({
  // process.env 환경변수를 이용하여 노출될 수 있는 정보들을 분리 보관 - 보안성 높임
  host: process.env.DB_URL,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

//db.connect
db.connect((err) => {
  if (!err) {
    console.log("Mysql DB Success");
  } else {
    console.log(err);
  }
});

//middle
app.use(express.json());
app.use(cors());

//url
app.get("/users", (req, res) => {
  //   console.log(req.query.searchQuery); 검색값이 넘어가는지
  const page = Number.parseInt(req.query.page);
  const offset = Number.parseInt(req.query.offset);
  const startNum = page * offset;

  // 검색어가 있으면 검색, 없으면 검색X
  const search = req.query.searchQuery || "";

  // 검색어를 이름으로 하거나 검색어를 이메일로 할 때도 검색이 되게
  // 만약 검색어가 없으면 조건을 빼고 검색

  // db 1 : 전체 게시물 수

  const nameSearch = "%" + search + "%";
  const emailSearch = "%" + search + "%";
  let sql =
    "SELECT COUNT(id) AS cnt FROM users WHERE name LIKE ? OR email LIKE ?;";
  db.query(sql, [nameSearch, emailSearch], (err, result) => {
    if (err) {
      throw err;
    } else {
      //   console.log(result[0].cnt); -> 10만개가 제대로 따라오는지

      // db 2 : 페이징 처리를 위한 쿼리 AND 검색 쿼리
      let dataSQL =
        "SELECT * FROM users WHERE name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT ?,?;";
      db.query(
        dataSQL,
        [nameSearch, emailSearch, startNum, offset],
        (err, users) => {
          if (err) {
            throw err;
          } else {
            // data -> react 보내는 방식 : res.send(), res.json();
            res.json({
              users,
              page,
              totalPageNum: Math.ceil(result[0].cnt / offset), // 전체 페이지 수
              totalRows: result[0].cnt,
            });
          }
        }
      );
    }
  });
});

//port
app.listen(process.env.PORT, () => console.log("Server Running 7777"));
