import "./App.css";
import axios from "axios";
import ReactPaginate from "react-paginate";
import { useEffect, useState } from "react";

function App() {
  const [users, setUsers] = useState([]); // 전체 데이터
  const [rows, setRows] = useState(0); // 전체 게시물 수
  const [page, setPage] = useState(0); // 현재 페이지
  const [pages, setPages] = useState(0); // 전체 페이지
  const [offset, setOffset] = useState(10); // 한 페이지에 표시할 데이터 수
  const [msg, setMsg] = useState(""); // 데이터 마지막에 표시하는 메세지
  const [searchWords, setSearchWords] = useState("");
  const [keyword, setKeyword] = useState("");

  useEffect(() => {
    const fetchdata = async () => {
      await axios
        .get(
          "http://localhost:7777/users?page=" +
            page +
            "&offset=" +
            offset +
            "&searchQuery=" +
            keyword
        )
        .then((response) => {
          setUsers(response.data.users);
          setPage(response.data.page);
          setPages(response.data.totalPageNum);
          setRows(response.data.totalRows);
        });
    };

    fetchdata();
  }, [page, keyword]); //[] -> 클릭이나 검색을 통해 상황에 따라 바뀌는 변수

  // 페이지 번호 누르면 page hook 값 바꾸기
  const changePage = ({ selected }) => {
    setPage(selected);

    if (selected === pages - 1) {
      setMsg("No More Data");
    } else {
      setMsg("");
    }
  };

  const searchData = (e) => {
    e.preventDefault();
    setKeyword(searchWords);
    setPage(0); // 검색 후 첫 페이지부터 보기 위해
    setSearchWords("");
  };

  return (
    <div className="container mt-5">
      {/* 검색기능 */}
      <div>
        <form method="post" onSubmit={searchData}>
          <input
            value={searchWords}
            type="text"
            onChange={(e) => setSearchWords(e.target.value)}
            placeholder="Search Words..."
          />
          <button type="submit">Search</button>
        </form>
      </div>

      <table className="table is-striped is-bordered is-fullwidth">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Gender</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, key) => {
            console.log(users);
            return (
              <tr key={key}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.gender}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <p>
        Total Rows : <strong>{rows}</strong>, page <strong>{page + 1}</strong>{" "}
        of <strong>{pages}</strong> Pages
      </p>
      <p className="has-text-centered has-text-danger">{msg}</p>
      <nav
        className="pagination is-centered"
        key={rows}
        role="navigation"
        aria-label="pagination"
      >
        {/* previousLabel = 이전 버튼 텍스트
        nextLabel = 이후 버튼 텍스트
        pageCount = 페니지 번호 개수
        onPageChange =  함수 : 마지막 페이지일 때 메세지 표시 */}

        {/* 디자인 옵션 */}
        <ReactPaginate
          previousLabel={"<Prev"}
          nextLabel={"Next>"}
          pageCount={pages}
          onPageChange={changePage}
          // 여기부터 디자인
          containerClassName={"pagination-list"}
          pageLinkClassName={"pagination-link"}
          previousLinkClassName={"pagination-previous"}
          nextLinkClassName={"pagination-next"}
          activeLinkClassName={"pagination-link is-current"}
          disabledLinkClassName={"pagination-link is-disabled"}
        />
      </nav>
    </div>
  );
}

export default App;
