use reactjs;
DROP TABLE users;

CREATE TABLE users(
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(100),
position VARCHAR(100),
attach VARCHAR(100),
regdate VARCHAR(100)
);


