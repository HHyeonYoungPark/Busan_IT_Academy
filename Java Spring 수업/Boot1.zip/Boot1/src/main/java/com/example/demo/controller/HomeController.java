package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.dao.BootDao;
import com.example.demo.dto.BootDto;

@Controller
public class HomeController {
	
	@Autowired
	BootDao dao;
	
	
	@GetMapping({"/","/list"})
	public String main(Model model){
//		model.addAttribute("data", dao.selectDataAll());
		
		List<BootDto> list = dao.selectDataAll();
		model.addAttribute("data", list);
		
		return "list";// list.html 파일임
	}
	
	
	@GetMapping("/writePage")
	public String write() {
		return "write"; // write.html파일
	}
	
	
	@PostMapping("/writeProc")
	public String writeProc(BootDto dto) {
		dao.insertData(dto);
		
		return "redirect:/list";
	}
	
	
	@GetMapping("/delete")
	public String delete(int idx) {
		dao.deleteData(idx);
		
		return "redirect:/list";
	}
	
	
	@GetMapping("/selectDataOne")
	public String selectDataOne(int idx, Model model) {
		BootDto one = dao.selectDataOne(idx);
		if(one!=null) {
			model.addAttribute("one", one);
		}
		return "update";
	}
	
	
	@PostMapping("/updateProc")
	public String updateProc(BootDto dto) {
		dao.updateData(dto);
		
		return "redirect:/list";
	}
	
}

