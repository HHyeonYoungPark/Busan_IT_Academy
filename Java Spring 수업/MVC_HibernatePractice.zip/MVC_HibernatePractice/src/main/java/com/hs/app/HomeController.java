package com.hs.app;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	
	@Autowired
	HiberDAO dao;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping({"/", "/selectAll"})
	public String home(Model model) {
		List<HiberDTO> list = dao.selectAll();
		
		model.addAttribute("list", list);
		
		return "home";
	}
	
	@RequestMapping("/insert")
	public String insert() {	
		return "insert";
	}
	
	
	@RequestMapping("/insertData")
	public String insertData(HiberDTO dto) {
		dao.insertData(dto);
		
		return "redirect:/";
	}
	
	
	@RequestMapping("/deleteData")
	public String deleteData(HiberDTO dto) {
		dao.deleteData(dto);
		return "redirect:/";
	}

	
	@RequestMapping("/updateData")
	public String updateData(HiberDTO dto) {
		dao.updateData(dto);
	return "redirect:/";
	}
	
	
	@RequestMapping("/viewData")
	public String viewData(HiberDTO dto) {
		dao.viewData(dto);
	return "view";
	}
	
	
	@RequestMapping("/selectOne")
	public String selectOne(Model model, HiberDTO dto) {
		// idx�� �̿��ؼ� Dto�� ���� �����;� �Ѵ�!
		HiberDTO d= dao.selectOne(dto);
		
		// �����°��� �𵨿� ��ƾ� �Ѵ�
		model.addAttribute("dto", d);
		
		return "one";
	}
	
}
