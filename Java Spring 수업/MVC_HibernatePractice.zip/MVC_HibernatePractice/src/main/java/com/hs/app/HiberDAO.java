package com.hs.app;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class HiberDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void insertData(HiberDTO dto) {
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		s.save(dto);
		t.commit();
	}
	
	
	public void deleteData(HiberDTO dto) {
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		s.delete(dto);
		t.commit();
	}
	
	
	public void updateData(HiberDTO dto) {
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		s.update(dto);
		t.commit();
	}
	
	
	public HiberDTO selectOne(HiberDTO dto) {
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		HiberDTO d = (HiberDTO) s.get(HiberDTO.class, dto.getIdx());
		t.commit();
		return d;
	}
	
	public HiberDTO viewData(HiberDTO dto) {
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		HiberDTO d = (HiberDTO) s.get(HiberDTO.class, dto.getIdx());
		t.commit();
		return d;
	}
	
	
	public List<HiberDTO> selectAll(){
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		
		List<HiberDTO> list = s.createCriteria(HiberDTO.class).list();
		t.commit();	
		return list;
	}
}
