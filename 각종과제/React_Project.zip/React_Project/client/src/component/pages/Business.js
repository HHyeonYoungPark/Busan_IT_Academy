import React from "react";

function Business() {
  return (
    <div>
      <h2>주요사업</h2>
    </div>
  );
}

export default Business;
