import React from "react";

function OpenInfo() {
  return (
    <div>
      <h2>정보공개</h2>
    </div>
  );
}

export default OpenInfo;
