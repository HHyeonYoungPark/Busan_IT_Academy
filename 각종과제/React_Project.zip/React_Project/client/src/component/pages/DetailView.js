import React from "react";

function DetailView() {
  return (
    <div>
      <h2>문화재 상세보기</h2>
    </div>
  );
}

export default DetailView;
