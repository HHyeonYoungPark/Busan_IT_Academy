import React from "react";

function Notice() {
  return (
    <div>
      <h2>공지사항</h2>
    </div>
  );
}

export default Notice;
