import React from "react";

function Introduction() {
  return (
    <div>
      <h2>재단소개</h2>
    </div>
  );
}

export default Introduction;
