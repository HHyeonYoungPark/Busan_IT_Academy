import "./App.css";
// axios, useState, useEffect
import axios from "axios";
import { useEffect, useState } from "react";

// page Number -> data

function App() {
  const [currentPageNumber, setCurrentPageNumber] = useState(1); // 첫 페이지 1
  const [viewDataPerPage, setViewDataPerPage] = useState(10); // 한 페이지에 몇개의 데이터?
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchdata = async () => {
      setLoading(true);
      await axios
        .get("https://jsonplaceholder.typicode.com/posts")
        .then((response) => {
          setPosts(response.data);
        });

      setLoading(false);
    };

    fetchdata();
  }, []);

  /*************************************/
  // 객체.slice(시작번호, 끝)
  const getEndDataNumber = currentPageNumber * viewDataPerPage;
  const getStartDataNumber = getEndDataNumber - viewDataPerPage;
  const currentPost = posts.slice(getStartDataNumber, getEndDataNumber);

  /*************************************/

  // pageNumber = Math.ceil(response.data / viewDataPerPage); -소수점이 나오면 Math.ceil();이용
  // html에서 for를 못 쓰기때문에 map 타입(객체)으로 바꿈
  const totalPageCount = [];
  for (let i = 1; i < Math.ceil(posts.length / viewDataPerPage) + 1; i++) {
    totalPageCount.push(i);
  }

  function pagination(pageNumber) {
    setCurrentPageNumber(pageNumber);
  }

  if (loading) {
    return <h1>Loading...</h1>;
  }

  return (
    <div>
      {/* content */}
      <h1> React Axios Pagination</h1>
      <ul>
        {currentPost.map((post, key) => {
          return (
            <li key={key}>
              <h5>{post.id}</h5>
              <h3>{post.title}</h3>
              <p>{post.body}</p>
            </li>
          );
        })}
      </ul>

      {/* page number   */}
      <div className="pagination">
        {/* html을 map 안에 출력하는 방식 -> return, () */}
        {totalPageCount.map((cnt, key) => {
          return (
            <span key={key} style={{ marginRight: "20px" }}>
              <a href="!#" onClick={(e) => pagination(cnt)}>
                {cnt}
              </a>
            </span>
          );
        })}
      </div>
    </div>
  );
}

export default App;
