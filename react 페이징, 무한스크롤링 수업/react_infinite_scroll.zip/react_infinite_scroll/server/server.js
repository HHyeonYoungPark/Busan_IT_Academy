require("dotenv").config();
const cors = require("cors");
const mysql = require("mysql");
const express = require("express");
const app = express();

//db
const db = mysql.createConnection({
  // process.env 환경변수를 이용하여 노출될 수 있는 정보들을 분리 보관 - 보안성 높임
  host: process.env.DB_URL,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

//db.connect
db.connect((err) => {
  if (!err) {
    console.log("Mysql DB Success");
  } else {
    console.log(err);
  }
});

//middle
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cors());

//url
app.get("/getUsers", (req, res) => {
  // url을 통해 넘어오는 숫자는 글자로 변환되기 때문에 다시 숫자로 parse해줌
  let startNum = Number.parseInt(req.query.startNum) || 0; // exception- 변수값이 제대로 전달이 안되면
  let offsetNum = Number.parseInt(req.query.offsetNum) || 20; // 예외처리로 값을 적어줌

  let sql = "SELECT * FROM users ORDER BY id DESC LIMIT ?, ?;";
  db.query(sql, [startNum, offsetNum], (err, users) => {
    if (err) {
      throw err;
    } else {
      res.send({
        users,
        // 기존 자료가 있으면 start+offset, 자료가 없다면 (처음부터 가져오기 0부터)
        startNum: users.length ? startNum + offsetNum : 0,
        offsetNum: offsetNum,
        // 읽어 올 자료가 20개 미만이면 더 읽어올 자료가 없기때문에 false
        moreDate: users.length >= offsetNum ? true : false,
      });
    }
  });
});

app.listen(process.env.PORT, () => console.log("Server Running 7777"));
