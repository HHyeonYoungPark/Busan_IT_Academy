import "./App.css";
import Users from "./components/Users";
import axios from "axios";
import { useEffect, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";

function App() {
  // select * from users limit ~~의 숫자 세팅
  const [startNum, setStartNum] = useState(0); // 처음 시작 컨텐츠 번호 0부터
  const [offsetNum, setOffSetNum] = useState(20); // 몇개씩 보여줄지
  const [users, setUsers] = useState([]); // 20개에 대한 데이터 저장
  const [hasMore, setHasMore] = useState(true); // 데이터가 없으면 나중에 false로 바뀌어야 함

  // startNum을 0, 20, 40, 60, 80 ...
  // 임시변수를 이용해서 startNum변수의 값을 바꾸기
  const [tmpNum, setTpmNum] = useState(0);

  // 변수=값 % 변수=값
  const getUsers = async () => {
    await axios
      .get(
        "http://localhost:7777/getUsers?startNum=" +
          startNum +
          "&offsetNum=" +
          offsetNum
      )
      .then((response) => {
        setUsers([...users, ...response.data.users]); // 기존자료 + 불러온 자료 - 스크롤 내리면 더보기 되지만 스크롤 올려도 이잔 정보들이 보여야 함
        setTpmNum(response.data.startNum);
        setOffSetNum(response.data.offsetNum);
        setHasMore(response.data.moreDate);
      });
    // 방법이 2가지다
    //await axios.get(`http://localhost:7777/getUsers?startNum=${startNum}&offSetNum=${offsetNum}`);
  };

  useEffect(() => {
    // getUsers(); 아래 주석 내용 넣으면 cmd 창에 warnning 안뜸
    getUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startNum]); // []는 값이 변할때마다 useEffect를 실행 시키니까
  // startNum - 다시 실행시킬때마다 자료를 가져오기

  const fetchData = () => {
    setStartNum(tmpNum); // 20, 20으로 넘어간다
  };

  return (
    <div className="wrapper">
      {/* 1. dataLength = {users.length} db에서 읽어오는 자료
      2. next = {다음 자료 읽어오는 함수}
      3. hasMore = {읽어올 자료가 있으면 true, 없으면 false}
      4. endMessage = {모든 자료를 표시한 후 메세지}
      5. loading = {자료를 읽어오기 전 메세지} 
      이 부분이 <InfiniteScroll ~~~~~> 에 들어가면 됩니다
      */}
      <InfiniteScroll
        dataLength={users.length}
        next={fetchData}
        hasMore={hasMore}
        endMessage={<h1>No More Data!</h1>}
        loading={<h1>Loading...</h1>}
      >
        <Users users={users} />
      </InfiniteScroll>
    </div>
  );
}

export default App;
