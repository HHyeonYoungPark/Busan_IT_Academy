import axios from "axios";

const SPRING_URL = "http://localhost:8899/api/article";

//중복되는 작업을 위해 class로 모듈화
class ArticleService {
  //전체 가져오기
  getArticles() {
    return axios.get(SPRING_URL);
  }
  //저장하기
  createArticle(article) {
    return axios.post(SPRING_URL, article);
  }
  //하나만 가져오기
  getArticleById() {
    return axios.get(SPRING_URL);
  }
  //수정하기
  updateArticle() {
    return axios.put(SPRING_URL);
  }
  //삭제하기
  deleteArticle() {
    return axios.delete(SPRING_URL);
  }
}
export default new ArticleService()