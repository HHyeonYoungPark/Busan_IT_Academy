import React from 'react'

const Footer = () => {
  return (
    <div><h3>Copyright by Busanit Academy</h3></div>
  )
}

export default Footer