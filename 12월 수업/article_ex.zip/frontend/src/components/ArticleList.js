import React from 'react'

const ArticleList = () => {
  return (
    <div>
      <a href="/create-article">Create Article</a>
      
    </div>
  )
}

export default ArticleList