import React from 'react'

const Header = () => {
  return (
    <div><h2>Busan it Article List</h2></div>
  )
}

export default Header