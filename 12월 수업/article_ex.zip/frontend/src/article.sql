create database article;

use article;

create table article(
  id bigint not null auto_increment primary key,
  subject varchar(255),
  writer varchar(30),
  content text,
  ref int,
  ref_step int,
  ref_level int,
  ip varchar(255),
  regdate datetime
);