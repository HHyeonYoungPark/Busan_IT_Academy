package com.example.backend.controller;


import com.example.backend.entity.Article;
import com.example.backend.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController //디자인 신경 쓸 필요없이 자료만 주고 받기
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class ArticleController {
    @Autowired
    private ArticleService articleService;

    @GetMapping("/article") //전체가져오기
    public List<Article> getArticles() {
        return articleService.getArticles();
    }

    @PostMapping("/article")
    public Article createArticle(@RequestBody Article article) { //메소드에는 타입과 변수명
        System.out.print("ok");
        System.out.print(article);
        return articleService.createArticle(article);
    }

    @DeleteMapping("/article/{id}")
    public void deleteArticle(@PathVariable long id) {
        articleService.deleteArticle(id);
    }
}
