package com.example.backend.service;

import com.example.backend.entity.Article;

import java.util.List;

public interface ArticleService {
    //본체가 없습니다. {} 없습니다. -> 접근제한자 반환형 메소드명();
    //전체가져오기
    public List<Article> getArticles();

    //저장하기
    public Article createArticle(Article article);

    public Article getArticleById(long id);

    public Article updateArticle(Article article, long id);

    public void deleteArticle(long id);
}
